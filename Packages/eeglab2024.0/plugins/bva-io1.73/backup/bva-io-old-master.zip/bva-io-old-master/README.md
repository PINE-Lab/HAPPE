This repository is a plugin for EEGLAB to import/export
Brain Vision Analyzer EEG data files.

# Version history
v1.7 - Better handling of VMRK and EEG file non-consistant witht the header VHDR file; allow empty marker info section; allow importing truncated binary file
